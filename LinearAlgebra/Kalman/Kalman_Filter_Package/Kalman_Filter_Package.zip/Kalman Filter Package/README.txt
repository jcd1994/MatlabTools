Kalman Filter Package Installation Instructions:

Make sure you choose Kalman Filter Package -> Add to Path -> Selected Folders And Subfolders

(Kalman Filter Package requires access to methods contained in its subfolders)

