
DXF Examples can be created using DXF_TEST.M script.

3D PDF files available in this directory were converted from DXF files using 
Bentley View software.