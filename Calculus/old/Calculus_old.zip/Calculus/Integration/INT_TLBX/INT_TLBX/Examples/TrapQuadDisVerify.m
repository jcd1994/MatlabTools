%% Verification of trapezoid quadrature rule for discrete data

%% Introduction
% The trapezoid rule quadrature error is estimated in the following
% cases:
%
% * Integration of a constant function at an even number of intervals
% * Integration of a constant function at an odd number of intervals
% * Integration of a constant function for randomly spaced x data
%
% Tables are printed which show the various quantities involved as function
% of increasing size of input data (number of function and independent
% variable pairs).
%

%% Integral of a constant for even number of intervals
% Define the values of the independent variable.
x=linspace(-5,7,8);
%%
% Define the values of the function.
f=pi*ones(size(x));
%%
% Integrate data
s=TrapQuadDis(x,f)
%%
% Absolute error
err=s-pi*(max(x)-min(x))

%% Integral of a constant for odd number of intervals
% Define the values of the independent variable.
x=linspace(-5,7,9);
%%
% Define the values of the function.
f=pi*ones(size(x));
%%
% Integrate data
s=TrapQuadDis(x,f)
%%
% Absolute error
err=s-pi*(max(x)-min(x))

%% Integral of a constant for randomly spaced x data
% Define the values of the independent variable.
x=sort(rand(5,1)-0.2);
%%
% Define the values of the function.
f=pi*ones(size(x));
%%
% Integrate data
s=TrapQuadDis(x,f)
%%
% Absolute error
err=s-pi*(max(x)-min(x))

%% Truncation error as function of the size of input data
% Starting and stopping points
xmin=-5*pi/7;
xmax=3*pi/5;
%%
% Initialize data
hold=-5;
errold=0;
%%
% Print table
fprintf('\nTruncation error test\n');
fprintf('  Data         Integral         Error    Convergence\n');
fprintf('  size            value                         rate\n');
% Loop through the discrete data sizes
for n=[10  17  25  100  315  2001  4522]
    % Define the values of the independent variable
    x=linspace(xmin,xmax,n);
    % Define the values of the function
    f=sin(x);
    % Integral
    s=TrapQuadDis(x,f);
    % Absolute error
    err=s-(cos(x(1))-cos(x(n)));
    % Subinterval length
    h=(xmax-xmin)/(n-1);
    % Print the result to the table
    fprintf(' %5d  %15.12f  %12.3e',n,s,err);
    % If hold<0 skip the test, else compute alpha
    if hold<0
        fprintf('\n');
    else
        fprintf('      %9.5f\n',log(err/errold)/log(h/hold));
    end
    % Save quantities for next iteration
    hold=h;
    errold=err;
end


%% Copyright
%
%  (c) 2016 by George Papazafeiropoulos
%  Captain, Infrastructure Engineer, Hellenic Air Force
%  Civil Engineer, M.Sc., Ph.D. candidate, NTUA
%
% Email: gpapazafeiropoulos@yahoo.gr
%
% Website: http://users.ntua.gr/gpapazaf/

