%% Verification of Newton-Cotes quadrature for discrete data

%% Introduction
% The Newton-Cotes quadrature error is estimated in the following cases:
%
% * Integration of a constant function
% * Integration of the sine function for various sizes of input data
% * Integration of the sine function for various numbers of integration
% points
%
% Tables are printed which show the various quantities involved as function
% of increasing size of input data (number of function and independent
% variable pairs) and as a function of increasing number of integration
% points.
%

%% Integral of a constant
% Define the values of the independent variable.
x=linspace(-5,7,121)';
%%
% Define the values of the function.
f=pi*ones(size(x));
%%
% Integrate the function for various numbers of integration points
s=zeros(6,1);
l=1;
for k=2:7
    s(l)=NCQuadDis(x,f,k);
    l=l+1;
end
%%
% Absolute error
err=s-pi*(max(x)-min(x))

%% Truncation error as function of the size of input data
% Starting and stopping points
xmin=-5*pi/7;
xmax=3*pi/5;
%%
% Different sizes of discrete data
m=[10 19 25 100 316 2002 4522];
%%
% Number of integration points to be applied for all data sizes.
k=4;
%%
% Initialize data
hold=-5;
errold=0;
%%
% Print table
fprintf('\nTruncation error test\n');
fprintf('  Data         Integral      Absolute    Convergence\n');
fprintf('  size            value         error           rate\n');
% Loop through the discrete data sizes
for n=m
    % Define the values of the independent variable
    x=linspace(xmin,xmax,n)';
    % Define the values of the function
    f=sin(x);
    % Integral
    s=NCQuadDis(x,f,k);
    % Absolute error
    err=s-(cos(x(1))-cos(x(n)));
    % Subinterval length
    h=(xmax-xmin)*(k-1)/(n-1);
    % Print the result to the table
    fprintf(' %5d  %15.12f  %12.3e',n,s,err);
    % If hold<0 skip the test, else compute alpha
    if hold<0
        fprintf('\n');
    else
        fprintf('      %9.5f\n',log(err/errold)/log(h/hold));
    end
    % Save quantities for next iteration
    hold=h;
    errold=err;
end

%% Truncation error as function of the number of integration points
% Starting and stopping points.
xmin=-5*pi/7;
xmax=3*pi/5;
%%
% Size of discrete data
m=121;
%%
% Different number of integration points.
k=[2 3 4 5 6 7 9 11];
%%
% Initialize data
hold=-5;
errold=0;
%%
% Print table
fprintf('\nTruncation error test\n');
fprintf('Integration           Integral      Absolute    Convergence\n');
fprintf('     points              value         error           rate\n');
% Loop through the number of integration points
for n=k
    % Define the values of the independent variable
    x=linspace(xmin,xmax,m)';
    % Define the values of the function
    f=sin(x);
    % Integral
    s=NCQuadDis(x,f,n);
    % Absolute error
    err=s-(cos(x(1))-cos(x(m)));
    % Subinterval length
    h=(xmax-xmin)*(n-1)/(m-1);
    % Print the result to the table
    fprintf('      %5d    %15.12f  %12.3e',n,s,err);
    % If hold<0 skip the test, else compute alpha
    if hold<0
        fprintf('\n');
    else
        fprintf('      %9.5f\n',log(err/errold)/log(h/hold));
    end
    % Save quantities for next iteration
    hold=h;
    errold=err;
end

%% Copyright
%
%  (c) 2016 by George Papazafeiropoulos
%  Captain, Infrastructure Engineer, Hellenic Air Force
%  Civil Engineer, M.Sc., Ph.D. candidate, NTUA
%
% Email: gpapazafeiropoulos@yahoo.gr
%
% Website: http://users.ntua.gr/gpapazaf/

