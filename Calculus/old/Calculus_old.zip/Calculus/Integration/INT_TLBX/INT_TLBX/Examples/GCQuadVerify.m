%% Verification of Gauss-Chebyshev quadrature

%% Introduction
% The Gauss-Chebyshev quadrature error is estimated in the case of
% integration of the function $xe^{-x}$ in $[-1,1]$. The integration is
% performed in the interval $[-1,1]$, using Gauss-Chebyshev integration
% points varying from $1$ to $20$.
%
% Tables are printed which show the various quantities involved as function
% of increasing integration points.
%
%% Initial definitions
% Lower limit of integration interval
a=-1;
%%
% Upper limit of integration interval
b=1;
%%
% Function to be integrated, divided by the weight function
y=@(x) x.*exp(-x).*sqrt(1-x.^2);
%%
% Exact value of the definite integral.
Iexact=-exp(-b)*(1+b)+exp(-a)*(1+a)
%% Truncation error as function of the number of integration points
% Print table
fprintf('\nGauss-Chebyshev quadrature\n');
fprintf('\n Integration        Integral    Absolute\n');
fprintf('      points           value       error\n');
% Loop through the number of integration points (n)
for n=1:20
    % Find Gauss-Chebyshev quadrature
    I=GCQuad(y,n);
    % Print the result to the table
    fprintf('      %6d   %13.10f   %9.2e\n',n,I,I-Iexact)
end

%% Copyright
%
%  (c) 2016 by George Papazafeiropoulos
%  Captain, Infrastructure Engineer, Hellenic Air Force
%  Civil Engineer, M.Sc., Ph.D. candidate, NTUA
%
% Email: gpapazafeiropoulos@yahoo.gr
%
% Website: http://users.ntua.gr/gpapazaf/

