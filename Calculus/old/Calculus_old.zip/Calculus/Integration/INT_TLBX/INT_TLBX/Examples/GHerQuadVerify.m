%% Verification of Gauss-Hermite quadrature

%% Introduction
% The Gauss-Hermite quadrature error is estimated in the case of
% integration of the function $x^2e^{-x^2}$ in $[-\infty,+\infty]$. The
% integration is performed in the interval $[-\infty,+\infty]$, using
% Gauss-Hermite integration points varying from $1$ to $8$.
%
% Tables are printed which show the various quantities involved as function
% of increasing integration points.
%
%% Initial definitions
% Function to be integrated, divided by the weight function $e^{-x^2}$
y=@(x) x.^2;
%%
% Exact value of the definite integral.
Iexact=sqrt(pi)/2;
%% Truncation error as function of the number of integration points

% Print table
fprintf('\nGauss-Hermite quadrature');
fprintf('\n Integration        Integral    Absolute\n');
fprintf('      points           value       error\n');
% Loop through the number of integration points (n)
for n=1:8
    % Find Gauss-Hermite quadrature
    I=GHerQuad(y,n);
    % Print the result to the table
    fprintf('      %6d   %13.10f   %9.2e\n',n,I,I-Iexact)
end

%% Copyright
%
%  (c) 2016 by George Papazafeiropoulos
%  Captain, Infrastructure Engineer, Hellenic Air Force
%  Civil Engineer, M.Sc., Ph.D. candidate, NTUA
%
% Email: gpapazafeiropoulos@yahoo.gr
%
% Website: http://users.ntua.gr/gpapazaf/

