%% Verification of Clenshaw-Curtis quadrature

%% Introduction
% The Clenshaw-Curtis quadrature error is estimated in the case of 
% integration of the function $xe^{-x}$ in $[0,5]$. The integration is
% performed in two ways:
%
% * Integration in the interval $[0,5]$ considered as a single subinterval,
% using Clenshaw-Curtis integration points varying from $1$ to $8$.
% * Integration in the interval $[0,5]$ using 3 Clenshaw-Curtis integration
% points in the interval $[a_k,b_k]$, where the ratio
% $\frac{b-a}{b_k-a_k}=\frac{5-0}{b_k-a_k}$ varies from $1$ to $8$.
%
% Tables are printed which show the various quantities involved as function
% of increasing integration points and increasing number of subintervals.
%
%% Initial definitions
% Lower limit of integration interval
a=0;
%%
% Upper limit of integration interval
b=5;
%%
% Function to be integrated
y=@(x) x.*exp(-x);
%%
% Number of subintervals used in integration point refinement test
np=1;
%%
% Number of integration points used in subinterval refinement test
nn=3;
%%
% Exact value of the definite integral.
Iexact=-exp(-b)*(1+b)+exp(-a)*(1+a);
%% Truncation error as function of the number of integration points
% Subinterval length
H=(b-a)/np;
%%
% Print table
fprintf('\nClenshaw-Curtis quadrature with %d subinterval(s), H = %f\n',np,H);
fprintf('\n Integration        Integral    Absolute\n');
fprintf('      points           value       error\n');
% Loop through the number of integration points (n)
for n=1:8
    % Find Clenshaw-Curtis quadrature for np subintervals
    I=CCQuad(y,a,b,np,n);
    % Print the result to the table
    fprintf('      %6d   %13.10f   %9.2e\n',n,I,I-Iexact)
end

%% Truncation error as function of the size of subintervals
% Set the initial value for k. alpha is computed only if k>1.
k=1;
%%
% Print table
fprintf('\nClenshaw-Curtis quadrature with %d integration points\n',nn);
fprintf('\n subintervals    subinterval        Integral     Absolute    Convergence\n');
fprintf('                      length           value        error           rate\n');
% Loop through the number of subintervals (nsubInt)
for nsubInt=1:8
    % Find Clenshaw-Curtis quadrature for nn integration points
    I=CCQuad(y,a,b,nsubInt,nn);
    % Absolute error
    err=I-Iexact;
    % Subinterval length
    H=(b-a)/nsubInt;
    % Print the result to the table
    fprintf('         %4d     %10.5f  %14.10f %12.2e',nsubInt,H,I,err);
    % If k>1 compute alpha, else do not
    if k>1
        fprintf('      %9.5f\n',log(err/errold)/log(H/HHold));
    else
        fprintf('\n');
    end
    % Save quantities for next iteration
    HHold=H;
    errold=err;
    % Update k
    k=k+1;
end

%% Copyright
%
%  (c) 2016 by George Papazafeiropoulos
%  Captain, Infrastructure Engineer, Hellenic Air Force
%  Civil Engineer, M.Sc., Ph.D. candidate, NTUA
%
% Email: gpapazafeiropoulos@yahoo.gr
%
% Website: http://users.ntua.gr/gpapazaf/

