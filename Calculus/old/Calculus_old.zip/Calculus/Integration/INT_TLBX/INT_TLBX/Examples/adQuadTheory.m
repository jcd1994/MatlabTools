%% Adaptive Numerical Quadrature Theory

%% Introduction
% If adaptive quadrature is applied for the calculation of the definite
% integral of the form:
%
% $$\int_{a}^b f(x)\,dx$$
% 
% then this general scheme is followed:
% 
% # procedure ADAPTIVE_QUADRATURE $(f,a,b,\tau)$
% # $$Q_1 \approx \int_a^bf(x)\,\mbox{d}x$$
% # $$m = (a + b) / 2$
% # $$Q_2 \approx \int_a^mf(x)\,\mbox{d}x + \int_m^bf(x)\,\mbox{d}x$
% # $$ \varepsilon \approx \left|Q_2 - Q_1\right|$
% # if $$ \varepsilon > \tau $$ then
% # $Q_2$ = ADAPTIVE_QUADRATURE $(f, a, m, \tau/2)$ + ADAPTIVE_QUADRATURE
% $(f, m, b, \tau/2)$
% # end if
% # return $$Q_2$
%
% In the above procedure, an approximation $Q_1$ to the integral of $f(x)$
% over the interval $\left[a,b\right]$ is computed (line 2). Then, the
% interval $\left[a,b\right]$ is divided into two equal subintervals
% $\left[a,\frac{a+b}{2}\right]=\left[a,m\right]$ and
% $\left[\frac{a+b}{2},b\right]=\left[m,b\right]$, at which two
% approximations to the integrals of $f(x)$ over them is computed (one
% approximation for each subinterval). The two approximate integrals are
% summed to give $Q_2$ (line 4). If the difference between $Q_1$ and $Q_2$
% is higher than a specified tolerance ($\tau$), then the whole adaptive
% integration procedure is applied twice, one time for each subinterval. In
% this way the initial interval $\left[a,b\right]$ is divided recursively
% in halves, until the difference between $Q_1$ and $Q_2$ becomes lower
% than the specified tolerance, or the number of recursive calls of
% ADAPTIVE_QUADRATURE exceeds a specified limit.
%
% The most important component of the above scheme is the quadrature rule
% used:
%
% $$Q \approx \int_a^bf(x)\,\mbox{d}x $$
%
% The functions included in this package which perform adaptive numerical
% integration (in alphabetical order) are the following:
%
% # adCCQuad.m
% # adGKQuad.m
% # adGLegQuad.m
% # adGLobQuad.m
% # adTrapQuad.m
%

%% Function adCCQuad.m
help adCCQuad.m

%% Function adGKQuad.m
help adGKQuad.m

%% Function adGLegQuad.m
help adGLegQuad.m

%% Function adGLobQuad.m
help adGLobQuad.m

%% Function adTrapQuad.m
help adTrapQuad.m

%% Copyright
%
%  (c) 2016 by George Papazafeiropoulos
%  Captain, Infrastructure Engineer, Hellenic Air Force
%  Civil Engineer, M.Sc., Ph.D. candidate, NTUA
%
% Email: gpapazafeiropoulos@yahoo.gr
%
% Website: http://users.ntua.gr/gpapazaf/

