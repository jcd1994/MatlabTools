%% Quadrature Rule Theory

%% Introduction
% The following quadrature rules are included in this toolbox (the adaptive
% ones not included):
%
% # Clenshaw-Curtis quadrature rule
% # Gauss-Chebyshev quadrature rule
% # Gauss-Hermite quadrature rule
% # Gauss�Kronrod quadrature rule
% # Gauss-Laguerre quadrature rule
% # Gauss-Legendre quadrature rule
% # Gauss-Lobatto quadrature rule
% # Newton-Cotes quadrature rule
% # Newton-Cotes quadrature rule for tabulated functions (discrete data)
% # Romberg's quadrature rule
% # Simpson's quadrature rule
% # Trapezoidal quadrature rule
% # Trapezoidal quadrature rule for tabulated functions (discrete data)
%
% Their corresponding functions are the following:
%
% # CCQuad.m
% # GCQuad.m
% # GHerQuad.m
% # GKQuad.m
% # GLagQuad.m
% # GLegQuad.m
% # GLobQuad.m
% # NCQuad.m
% # NCQuadDis.m
% # RombQuad.m
% # SQuad.m
% # TrapQuad.m
% # TrapQuadDis.m
%

%% Clenshaw-Curtis quadrature rule
% The definite integral of the form:
%
% $$\int_a^b f(x)\,dx$$
%
% can be calculated approximately using the Clenshaw-Curtis integration
% points (nodes and weights) in the integration interval $[-1,1]$:
%
% $$\int_{-1}^1 f(x)\,dx \approx \sum_{i=1}^n w_i f(x_i).$$
%
% or using the Clenshaw-Curtis integration points (nodes and weights) in
% equally spaced subintervals $[a_k,b_k]$ of $[-1,1]$:
%
% $$\int_{-1}^1 f(x)\,dx \approx \sum_{k=1}^m \sum_{i=1}^n w_i,_k
% f(x_i,_k).$$
%
% where the interval $[-1,1]$ is divided into $m$ subintervals of the form:
%
% $$[a_1,b_1],[a_2,b_2],[a_3,b_3],...[a_m,b_m]$$
%
% and $a_1=-1$, $b_m=1$. $w_i,_k$ is the Clenshaw-Curtis weight of the $i$ th
% integration point in the $k$ th subinterval. Similarly, $x_i,_k$ is the
% Clenshaw-Curtis coordinate (node) of the $i$ th integration point in the
% $k$ th subinterval. For the mapping of $x_i$ belonging to the interval
% $[-1,1]$ to $x_i,_k$ belonging to the interval $[a_k,b_k]$, see the
% function CCQuad.m.
%
help CCQuad

%% Gauss-Chebyshev quadrature rule
% The definite integral of the form:
%
% $$\int_{-1}^{+1} \frac {f(x)} {\sqrt{1-x^2} }\,dx$$
%
% can be calculated approximately using the Gauss-Chebyshev integration
% points (nodes and weights) in the integration interval $[-1,1]$:
%
% $$\int_{-1}^{+1} \frac {f(x)} {\sqrt{1-x^2} }\,dx \approx \sum_{i=1}^n
% w_i f(x_i)$$
%
help GCQuad

%% Gauss-Hermite quadrature rule
% The definite integral of the form:
%
% $$\int_{-\infty}^{+\infty} e^{-x^2}f(x)\,dx$$
%
% can be calculated approximately using the Gauss-Hermite integration
% points (nodes and weights) in the integration interval
% $[-\infty,+\infty]$:
%
% $$\int_{-\infty}^{+\infty} e^{-x^2}f(x)\,dx \approx \sum_{i=1}^n w_i
% f(x_i).$$
%
help GHerQuad

%% Gauss-Kronrod quadrature rule
% The definite integral of the form:
%
% $$\int_a^b f(x)\,dx$$
%
% can be calculated approximately using the Gauss-Kronrod integration
% points (nodes and weights) in the integration interval $[-1,1]$:
%
% $$\int_{-1}^1 f(x)\,dx \approx \sum_{i=1}^n w_i f(x_i).$$
%
% or using the Gauss-Kronrod integration points (nodes and weights) in
% equally spaced subintervals $[a_k,b_k]$ of $[-1,1]$:
%
% $$\int_{-1}^1 f(x)\,dx \approx \sum_{k=1}^m \sum_{i=1}^n w_i,_k
% f(x_i,_k).$$
%
% where the interval $[-1,1]$ is divided into $m$ subintervals of the form:
%
% $$[a_1,b_1],[a_2,b_2],[a_3,b_3],...[a_m,b_m]$$
%
% and $a_1=-1$, $b_m=1$. $w_i,_k$ is the Gauss-Kronrod weight of the $i$ th
% integration point in the $k$ th subinterval. Similarly, $x_i,_k$ is the
% Gauss-Kronrod coordinate (node) of the $i$ th integration point in the
% $k$ th subinterval. For the mapping of $x_i$ belonging to the interval
% $[-1,1]$ to $x_i,_k$ belonging to the interval $[a_k,b_k]$, see the
% function GKQuad.m.
%
help GKQuad

%% Gauss-Laguerre quadrature rule
% The definite integral of the form:
%
% $$\int_{0}^{+\infty} e^{-x}f(x)\,dx$$
%
% can be calculated approximately using the Gauss-Laguerre integration
% points (nodes and weights) in the integration interval $[0,+\infty]$:
%
% $$\int_{0}^{+\infty} e^{-x}f(x)\,dx \approx \sum_{i=1}^n w_i f(x_i).$$
%
help GLagQuad

%% Gauss-Legendre quadrature rule
% The definite integral of the form:
%
% $$\int_a^b f(x)\,dx$$
%
% can be calculated approximately using the Gauss-Legendre integration
% points (nodes and weights) in the integration interval $[-1,1]$:
%
% $$\int_{-1}^1 f(x)\,dx \approx \sum_{i=1}^n w_i f(x_i).$$
%
% or using the Gauss-Legendre integration points (nodes and weights) in
% equally spaced subintervals $[a_k,b_k]$ of $[-1,1]$:
%
% $$\int_{-1}^1 f(x)\,dx \approx \sum_{k=1}^m \sum_{i=1}^n w_i,_k
% f(x_i,_k).$$
%
% where the interval $[-1,1]$ is divided into $m$ subintervals of the form:
%
% $$[a_1,b_1],[a_2,b_2],[a_3,b_3],...[a_m,b_m]$$
%
% and $a_1=-1$, $b_m=1$. $w_i,_k$ is the Gauss-Legendre weight of the $i$
% th integration point in the $k$ th subinterval. Similarly, $x_i,_k$ is
% the Gauss-Legendre coordinate (node) of the $i$ th integration point in
% the $k$ th subinterval. For the mapping of $x_i$ belonging to the
% interval $[-1,1]$ to $x_i,_k$ belonging to the interval $[a_k,b_k]$, see
% the function GLegQuad.m.
%
help GLegQuad

%% Gauss-Lobatto quadrature rule
% The definite integral of the form:
%
% $$\int_a^b f(x)\,dx$$
%
% can be calculated approximately using the Gauss-Lobatto integration
% points (nodes and weights) in the integration interval $[-1,1]$:
%
% $$\int_{-1}^1 f(x)\,dx \approx \sum_{i=1}^n w_i f(x_i).$$
%
% or using the Gauss-Lobatto integration points (nodes and weights) in
% equally spaced subintervals $[a_k,b_k]$ of $[-1,1]$:
%
% $$\int_{-1}^1 f(x)\,dx \approx \sum_{k=1}^m \sum_{i=1}^n w_i,_k
% f(x_i,_k).$$
%
% where the interval $[-1,1]$ is divided into $m$ subintervals of the form:
%
% $$[a_1,b_1],[a_2,b_2],[a_3,b_3],...[a_m,b_m]$$
%
% and $a_1=-1$, $b_m=1$. $w_i,_k$ is the Gauss-Lobatto weight of the $i$ th
% integration point in the $k$ th subinterval. Similarly, $x_i,_k$ is the
% Gauss-Lobatto coordinate (node) of the $i$ th integration point in the
% $k$ th subinterval. For the mapping of $x_i$ belonging to the interval
% $[-1,1]$ to $x_i,_k$ belonging to the interval $[a_k,b_k]$, see the
% function GLobQuad.m.
%
help GLobQuad

%% Newton-Cotes quadrature rule
% The definite integral of the form:
%
% $$\int_a^b f(x)\,dx$$
%
% can be calculated approximately using the Newton-Cotes integration
% points (nodes and weights) in the integration interval $[-1,1]$:
%
% $$\int_{-1}^1 f(x)\,dx \approx \sum_{i=1}^n w_i f(x_i).$$
%
% or using the Newton-Cotes integration points (nodes and weights) in
% equally spaced subintervals $[a_k,b_k]$ of $[-1,1]$:
%
% $$\int_{-1}^1 f(x)\,dx \approx \sum_{k=1}^m \sum_{i=1}^n w_i,_k
% f(x_i,_k).$$
%
% where the interval $[-1,1]$ is divided into $m$ subintervals of the form:
%
% $$[a_1,b_1],[a_2,b_2],[a_3,b_3],...[a_m,b_m]$$
%
% and $a_1=-1$, $b_m=1$. $w_i,_k$ is the Newton-Cotes weight of the $i$ th
% integration point in the $k$ th subinterval. Similarly, $x_i,_k$ is the
% Newton-Cotes coordinate (node) of the $i$ th integration point in the
% $k$ th subinterval. For the mapping of $x_i$ belonging to the interval
% $[-1,1]$ to $x_i,_k$ belonging to the interval $[a_k,b_k]$, see the
% function NCQuad.m.
%
help NCQuad

%% Newton-Cotes quadrature rule for discrete data
% In order to calculate the definite integral of the form:
%
% $$\int_a^b f(x)\,dx$$
%
% when $f$ is defined by its values at certain values of $x$, the discrete
% version of the Newton-Cotes quadrature rule can be used (i.e. the
% function NCQuadDis). Let $f_1,f_2,...,f_m$ be the discrete values of the
% function to be integrated. The definite integral is given by:
%
% $$\int_{a}^{b} f(x)\, dx \approx \sum_{i=1}^{n} \sum_{j=1}^{k}
% w_jf_{\left[\left(i-1\right)\left(k-1\right)+j\right]} $$
%
% where $n$ is the number of subintervals and $k$ is the number of
% integration points in each subinterval. The number of subintervals in
% which the integration takes place is given by the relation:
%
% $$n = \frac{m-1}{k-1}$$
%
% Note that the right hand side of the last equation has to be always a
% positive integer.
%
help NCQuadDis

%% Romberg quadrature rule
% The definite integral of the form:
%
% $$\int_a^b f(x)\,dx$$
% 
% can be calculated by applying Richardson extrapolation repeatedly on the
% trapezoidal rule. The Romberg method can be defined inductively as
% follows:
% 
% $$R(0,0) = \frac{1}{2} (b-a) (f(a) + f(b))$$
% 
% $$R(n,0) = \frac{1}{2} R(n-1,0) + h_n \sum_{k=1}^{2^{n-1}} f(a +
% (2k-1)h_n)$$
% 
% $$R(n,m) = R(n,m-1) + \frac{1}{4^{m}-1} (R(n,m-1) - R(n-1,m-1))$$
% 
% or
% 
% $$R(n,m) = \frac{1}{4^{m}-1} ( 4^{m} R(n,m-1) - R(n-1,m-1))$$
% 
% where
% 
% $$n \ge m$$ , $$m \ge 1$$ , $$h_n = \frac{b-a}{2^n}$$
% 
% * $R(n,0)$ (zeroeth extrapolation) is equivalent to the trapezoidal rule
% with $$2n+1$ points.
% * $R(n,1)$ (first extrapolation) is equivalent to Simpson's rule with
% $$2n+1$ points.
% * $R(n,2)$ (second extrapolation) is equivalent to Boole's rule with
% $$2n+1$ points.
%
% Further Romberg extrapolations differ from Newton-Cotes formulas in that
% the latter methods produce increasingly differing weights, eventually
% leading to large positive and negative weights, which does not happen in
% the former methods. This is the reason for which Newton-Cotes methods
% fail to converge for higher degrees, while Romberg integration is more
% stable.
%
help RombQuad

%% Simpson's quadrature rule
% The definite integral of the form:
%
% $$\int_a^b f(x)\,dx$$
%
% can be calculated by the following approximation:
%
% $$\int_{a}^{b} f(x) \, dx \approx \frac{b-a}{6}\left[f(a) +
% 4f\left(\frac{a+b}{2}\right)+f(b)\right]$$
%
% If the interval of integration $[a,b]$ is in some sense "small" (i.e. the
% function being integrated is relatively smooth over the interval), then
% Simpson's rule will provide an adequate approximation to the exact
% integral.
%
% If the function to be integrated is not smooth over the interval (i.e.
% either the function is highly oscillatory, or it is not differentiable at
% certain points), to avoid inaccurate results, the interval $[a,b]$ can
% be divided into a number of "small" subintervals. Simpson's rule is then
% applied to each subinterval, with the results being summed to produce an
% approximation for the integral over the entire interval. This approach is
% called the composite Simpson's rule.
% 
% Suppose that the interval $[a,b]$ is split up in $n$ subintervals, with
% $n$ an even number. Then, the composite Simpson's rule is given by:
%
% $$\int_a^b f(x) \,
% dx\approx\frac{h}{3}\bigg[f(x_0)+2\sum_{j=1}^{n/2-1}f(x_{2j})+
% 4\sum_{j=1}^{n/2}f(x_{2j-1})+f(x_n) \bigg]$$
%
% where $x_j=a+jh$ for $j=0, 1, ..., n-1, n$ with $h=(b-a)/n$. In
% particular, $x_0=a$ and $x_n=b$.
%
help SQuad

%% Trapezoid quadrature rule
% The definite integral of the form:
%
% $$\int_a^b f(x)\,dx$$
%
% can be calculated by approximating the region under the graph of the
% function $f(x)$ as a trapezoid and calculating its area, namely:
%
% $$\int_{a}^{b} f(x)\, dx \approx (b-a) \left[\frac{f(a) + f(b)}{2}
% \right]. $$
%
% Alternatively, one can use the above rule to $N$ equally spaced
% subintervals $[a_k,b_k]$ of $[a,b]$, or $N+1$ grid points $a = x_1 < x_2
% < ... < x_{N+1} = b$, where the grid spacing is $h=(b-a)/N$:
%
% $$\int_{a}^{b} f(x)\, dx \approx \frac{b-a}{2N} \sum_{k=1}^{N} \left(
% f(x_{k+1}) + f(x_{k}) \right)$$
%
help TrapQuad

%% Trapezoid quadrature rule for discrete data
% In order to calculate the definite integral of the form:
%
% $$\int_a^b f(x)\,dx$$
%
% when $f$ is defined by its values at certain values of $x$, the discrete
% version of the composite trapezoid rule can be used (i.e. the function
% TrapQuadDis). Let $f_1,f_2,...,f_n$ and $x_1,x_2,...,x_n$ be the values
% of the function and the independent variable respectively. The definite
% integral is given by:
%
% $$\int_{a}^{b} f(x)\, dx \approx \sum_{k=1}^{n-1}
% \left[\left(x_{k+1}-x_k\right)\frac{f_k+f_{k+1}}{2} \right]. $$
%
help TrapQuadDis

%% Copyright
%
%  (c) 2016 by George Papazafeiropoulos
%  Captain, Infrastructure Engineer, Hellenic Air Force
%  Civil Engineer, M.Sc., Ph.D. candidate, NTUA
%
% Email: gpapazafeiropoulos@yahoo.gr
%
% Website: http://users.ntua.gr/gpapazaf/

