%% Verification of adaptive Clenshaw-Curtis quadrature
% The results of the adaptive Clenshaw-Curtis quadrature are compared to
% the results of MATLAB's function quadl. Tables are printed which
% demonstrate the convergence of the adaptive Clenshaw-Curtis quadrature as
% error tolerance decreases.
%
%% Initial definitions
% Number of subintervals
nSubInt=1;
%%
% Number of integration points
nIntP=4;
%%
% Relative and absolute error tolerances
t=[5e-2 5e-3 5e-5 5e-6];
tol=[t;t];
%%
% Maximum level of recursion
maxLevel=16;
%% Evaluate the bessel function from its integral form
% Define the Bessel function of the first kind
fun=inline('cos(z*sin(x) - nu*x)','x','nu','z');
%%
% Order of the Bessel function
nu=2;
%%
% Value of the independent variable
z=8;
%%
% Evaluate $J_2(8)$ using the related function of MATLAB
Je=besselj(nu,z);
%%
% Evaluate $J_2(8)$ using adaptive quadrature and MATLAB's quadl function,
% for the various tolerances specified above
for i=1:size(tol,2)
    JCC(i)=adCCQuad(fun,0,pi,nSubInt,nIntP,tol(:,i),maxLevel,0,0,nu,z)/pi;
    JL(i)=quadl(fun,0,pi,tol(:,i),[],nu,z)/pi;
end
%%
% Errors in the numerical values of the two integrals compared to the
% straightforward function definition
eL=JL-Je;
eCC=JCC-Je;
%%
% Summarize the results in a table
fprintf('\nComputed J%d(%f):\n',nu,z)
fprintf('\n    Relative      Adaptive         quadl\n');
fprintf('   Tolerance    Quadrature         Error\n');
fprintf('                     Error              \n');
for i=1:length(tol)
    fprintf('%12.2e  %12.2e  %12.2e\n',tol(1,i),eCC(i),eL(i));
end

%% Integrate the humps function
% Define the humps function
c=[0.3,0.01,0.9,0.04,-6];
fhumps=@(x) 1./((x-c(1)).^2+c(2))+1./((x-c(3)).^2+c(4))+c(5);
%%
% Lower limit of integration
a=0;
%%
% Upper limit of integration
b=2;
%%
% Exact value of integral of the humps function on [a,b]
Ie=(atan((c(1)-a)/sqrt(c(2)))-atan((c(1)-b)/sqrt(c(2))))/sqrt(c(2))...
    +(atan((c(3)-a)/sqrt(c(4)))-atan((c(3)-b)/sqrt(c(4))))/sqrt(c(4))...
    +c(5)*(b-a);
%%
% Evaluate the integral using adaptive quadrature and MATLAB's quadl
% function, for the various tolerances specified above
for i=1:length(tol)
    ICC(i)=adCCQuad(fhumps,a,b,nSubInt,nIntP,tol(:,i),maxLevel,0,0);
    IL(i)=quadl(fhumps,a,b,tol(:,i));
end
%%
% Errors in the numerical values of the two integrals compared to the
% exact value
eL=IL-Ie;
eCC=ICC-Ie;
%%
% Summarize the results in a table
fprintf('\nIntegral of humps from %f to %f:\n',a,b)
fprintf('\n    Relative      Adaptive         quadl\n');
fprintf('   Tolerance    Quadrature         Error\n');
fprintf('                     Error              \n');
for i=1:length(tol)
    fprintf('%12.2e  %12.2e  %12.2e\n',tol(1,i),eCC(i),eL(i));
end

%% Copyright
%
%  (c) 2016 by George Papazafeiropoulos
%  Captain, Infrastructure Engineer, Hellenic Air Force
%  Civil Engineer, M.Sc., Ph.D. candidate, NTUA
%
% Email: gpapazafeiropoulos@yahoo.gr
%
% Website: http://users.ntua.gr/gpapazaf/


