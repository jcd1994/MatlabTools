%% Verification of Newton-Cotes quadrature

%% Trapezoidal rule (n=2)
% Calculate
n=2;
[x1,w1]=NCIntP(n-1);
%%
% Verify
x2(1) = -1;     x2(2) = -x2(1);
w2(1) =  1/2;   w2(2) =  w2(1);
max(abs(x1'-x2))<1e-6 && max(abs(w1'-w2))<1e-6
%% Simpson's rule (n=3)
% Calculate
n=3;
[x1,w1]=NCIntP(n-1);
%%
% Verify
x2(1) = -1;    x2(2) =  0;      x2(3) = -x2(1);
w2(1) =  1/6;  w2(2) =  4/6;    w2(3) =  w2(1);
max(abs(x1'-x2))<1e-6 && max(abs(w1'-w2))<1e-6
%% Simpson's 3/8 rule (n=4)
% Calculate
n=4;
[x1,w1]=NCIntP(n-1);
%%
% Verify
x2(1) = -1;     x2(4) = -x2(1);
x2(2) = -1/3;   x2(3) = -x2(2);
w2(1) = 1/8;    w2(4) =  w2(1);
w2(2) = 3/8;    w2(3) =  w2(2);
max(abs(x1'-x2))<1e-6 && max(abs(w1'-w2))<1e-6
%% Milne rule (n=5)
% Calculate
n=5;
[x1,w1]=NCIntP(n-1);
%%
% Verify
x2(1) = -1;     x2(5) = -x2(1);
x2(2) = -0.5;   x2(4) = -x2(2);
x2(3) =  0;
w2(1) =  7/90;  w2(5) =  w2(1);
w2(2) =  32/90; w2(4) =  w2(2);
w2(3) =  12/90;
max(abs(x1'-x2))<1e-6 && max(abs(w1'-w2))<1e-6
%% Newton-Cotes quadrature for n=6
% Calculate
n=6;
[x1,w1]=NCIntP(n-1);
%%
% Verify
x2(1) = -1;       x2(6) = -x2(1);
x2(2) = -0.6;     x2(5) = -x2(2);
x2(3) = -0.2;     x2(4) = -x2(3);
w2(1) = 19/288;   w2(6) = w2(1);
w2(2) = 75/288;   w2(5) = w2(2);
w2(3) = 50/288;   w2(4) = w2(3);
max(abs(x1'-x2))<1e-6 && max(abs(w1'-w2))<1e-6
%% Weddle rule (n=7)
% Calculate
n=7;
[x1,w1]=NCIntP(n-1);
%%
% Verify
x2(1) = -1;       x2(7) = -x2(1);
x2(2) = -2/3;     x2(6) = -x2(2);
x2(3) = -1/3;     x2(5) = -x2(3);
x2(4) = 0;
w2(1) = 41/840;   w2(7) =  w2(1);
w2(2) = 216/840;  w2(6) =  w2(2);
w2(3) = 27/840;   w2(5) =  w2(3);
w2(4) = 272/840;
max(abs(x1'-x2))<1e-6 && max(abs(w1'-w2))<1e-6

%% Copyright
%
%  (c) 2016 by George Papazafeiropoulos
%  Captain, Infrastructure Engineer, Hellenic Air Force
%  Civil Engineer, M.Sc., Ph.D. candidate, NTUA
%
% Email: gpapazafeiropoulos@yahoo.gr
%
% Website: http://users.ntua.gr/gpapazaf/

