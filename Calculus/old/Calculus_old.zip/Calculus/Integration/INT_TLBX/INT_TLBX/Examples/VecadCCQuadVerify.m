%% Vectorized verification of adaptive Clenshaw-Curtis quadrature
% The function implementing the adaptive Clenshaw-Curtis quadrature is run
% in a vectorized way, namely it performs numerical integration for
% different integration intervals with one action. The limits of
% integration are vectors of the form:
%
% $$a=\left[ a_1 \ a_2 \ \dots \ a_m \right]'$$, $$b=\left[ b_1 \ b_2
% \ \dots \ b_m \right]'$$
%
%
%% Initial definitions
% Number of subintervals of each interval
nSubInt=1;
%%
% Number of integration points of each interval
nIntP=4;
%%
% Relative and absolute error tolerances
tol=[5e-6;5e-6];
%%
% Maximum level of recursion
maxLevel=16;
%%
% Define a vectorized parabolic function
fun=@(x) x.^2;
%%
% Lower integration limit
a=[0;1;2;3;4];
%%
% Upper integration limit
b=[2;10;4;6;20];
%%
% Exact values of integrals
Iexact=(b.^3-a.^3)/3
%% Adaptive numerical integration
% Numerical results
Inum=adCCQuad(fun,a,b,nSubInt,nIntP,tol,maxLevel,0,0)
%%
% Error checking
if any(abs(Iexact-Inum)>5e-6)
    error('The adCCQuad function does not perform correctly')
end

%% Copyright
%
%  (c) 2016 by George Papazafeiropoulos
%  Captain, Infrastructure Engineer, Hellenic Air Force
%  Civil Engineer, M.Sc., Ph.D. candidate, NTUA
%
% Email: gpapazafeiropoulos@yahoo.gr
%
% Website: http://users.ntua.gr/gpapazaf/


