%% Verification of trapezoid quadrature rule

%% Introduction
% The trapezoid rule quadrature error is estimated in the case of
% integration of the function $xe^{-x}$ in $[0,5]$. The integration is
% performed using the rule in the interval $[a_k,b_k]$, where the ratio
% $N=\frac{b-a}{b_k-a_k}$ takes the following values: $2, 4, 8, 16, 32, 64,
% 128, 256$.
%
% Tables are printed which show the various quantities involved as function
% of increasing number of subintervals.
%
%% Initial definitions
% Lower limit of integration interval
a=0;
%%
% Upper limit of integration interval
b=5;
%%
% Function to be integrated
y=@(x) x.*exp(-x);
%%
% Exact value of the definite integral.
Iexact=-exp(-b)*(1+b)+exp(-a)*(1+a)
%% Truncation error as function of the size of subintervals
% Set the initial value for k. alpha is computed only if k>1.
k=1;
%%
% Print table
fprintf('\nTrapezoid rule quadrature\n');
fprintf('\n  integration    subinterval        Integral     Absolute     Convergence\n');
fprintf('       points         length           value        error            rate \n');
% Loop through the number of subintervals (nsubInt)
for nsubInt=[ 2 4 8 16 32 64 128 256]
    % Find trapezoid rule quadrature
    I = TrapQuad(y,a,b,nsubInt);
    % Absolute error
    err=I-Iexact;
    % Number of integration points
    nIntP=nsubInt+1;
    % Subinterval length
    H=(b-a)/nsubInt;
    % Print the result to the table
    fprintf('         %4d     %10.5f  %14.10f %12.2e',nIntP,H,I,err);
    % If k>1 compute alpha, else do not
    if k>1
        fprintf('       %9.5f\n',log(err/errold)/log(H/HHold));
    else
        fprintf('\n');
    end
    % Save quantities for next iteration
    HHold=H;
    errold=err;
    % Update k
    k=k+1;
end

%% Copyright
%
%  (c) 2016 by George Papazafeiropoulos
%  Captain, Infrastructure Engineer, Hellenic Air Force
%  Civil Engineer, M.Sc., Ph.D. candidate, NTUA
%
% Email: gpapazafeiropoulos@yahoo.gr
%
% Website: http://users.ntua.gr/gpapazaf/

