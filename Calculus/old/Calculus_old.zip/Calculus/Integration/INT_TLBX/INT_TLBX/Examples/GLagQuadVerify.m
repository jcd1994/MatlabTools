%% Verification of Gauss-Laguerre quadrature

%% Introduction
% The Gauss-Laguerre quadrature error is estimated in the case of
% integration of the function $x^2e^{-x}$ in $[0,+\infty]$. The integration
% is performed in the interval $[0,+\infty]$, using Gauss-Laguerre
% integration points varying from $1$ to $8$.
%
% Tables are printed which show the various quantities involved as function
% of increasing integration points.
%
%% Initial definitions
% Function to be integrated, divided by the weight function $e^{-x}$
y=@(x) x.^2;
%%
% Exact value of the definite integral.
Iexact=2;
%% Truncation error as function of the number of integration points

% Print table
fprintf('\nGauss-Laguerre quadrature');
fprintf('\n Integration        Integral    Absolute\n');
fprintf('      points           value       error\n');
% Loop through the number of integration points (n)
for n=1:8
    % Find Gauss-Laguerre quadrature
    I=GLagQuad(y,n);
    % Print the result to the table
    fprintf('      %6d   %13.10f   %9.2e\n',n,I,I-Iexact)
end

%% Copyright
%
%  (c) 2016 by George Papazafeiropoulos
%  Captain, Infrastructure Engineer, Hellenic Air Force
%  Civil Engineer, M.Sc., Ph.D. candidate, NTUA
%
% Email: gpapazafeiropoulos@yahoo.gr
%
% Website: http://users.ntua.gr/gpapazaf/

