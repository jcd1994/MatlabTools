function [I,xq,wq]=CCQuad(fun,a,b,nSubInt,nIntP,varargin)
% Composite Clenshaw-Curtis quadrature
%
% Description
%     [#I#,#xq#,#wq#]=CCQuad(#fun#,#a#,#b#,#nSubInt#,#nIntP#,#varargin#)
%     calculates the approximate value of the definite integral from #a# to
%     #b# of #fun#(x)*dx. The integration can be done either in a single
%     interval ([#a#,#b#]), or in multiple subintervals of equal length,
%     starting from #a# and ending to #b#. Between #I#, #xq# and #wq# the
%     following equality holds:
%     #I#=sum(#wq#.*feval(#fun#,#xq#,varargin{:}),2)
%
% Input arguments
%     #fun# (function handle or name of m file defining a function) is the
%     function to be integrated.
%     #a# ([#n# x 1]) is the lower limit of the integration interval.
%     #b# ([#n# x 1]) is the upper limit of the integration interval.
%     #nSubInt# (scalar) is the number of equal subintervals of the
%     interval [#a#,#b#] at which the function #fun# will be integrated.
%     #nIntP# (scalar) is the number of integration points at which the
%     function #fun# will be evaluated at each subinterval.
%     #varargin# (cell) contains additional arguments to be passed to the
%     function #fun# in order to be evaluated.
%
% Output arguments
%     #I# ([#n# x 1]) is the approximate value of the definite integral
%     from #a# to #b# of #fun#(x)*dx.
%     #xq# ([#n# x #nSubInt#*#nIntP#]) is the nodes used for the
%     quadrature.
%     #wq# ([#n# x #nSubInt#*#nIntP#]) is the weights used for the
%     quadrature.
%
% Parents (calling functions)
%     adCCQuad > CCQuad
%
% Children (called functions)
%     CCQuad > CCIntP
%

% __________________________________________________________________________
%% Copyright
%
%  (c) 2016 by George Papazafeiropoulos
%  Captain, Infrastructure Engineer, Hellenic Air Force
%  Civil Engineer, M.Sc., Ph.D. candidate, NTUA
%
% Email: gpapazafeiropoulos@yahoo.gr
%
% Website: http://users.ntua.gr/gpapazaf/
%

a=a(:);
b=b(:);
n=numel(a);
if numel(b)~=n
    error('Lower and upper limits must have the same size')
elseif ~isscalar(nSubInt)
    error('The number of subintervals must be a scalar')
elseif ~isscalar(nIntP)
    error('The number of integration points must be a scalar')
end
fun=fcnchk(fun);
try
    fa=feval(fun,a,varargin{:});
    fb=feval(fun,b,varargin{:});
catch err1
    error('The integrand must be defined in [a,b]')
end
if numel(fa)~=n || numel(fb)~=n
    error('The integrand must be scalar valued')
end
try
    feval(fun,a(:,[1 1]),varargin{:});
catch err1
    error('The integrand must be vectorized')
end
[z,wt]=CCIntP(nIntP);
H=(b-a)/nSubInt;
H2=H/2;
x=a(:,ones(1,nSubInt+1))+cumsum([zeros(n,1),H(:,ones(1,nSubInt))],2);
xmid=permute((x(:,1:end-1)+x(:,2:end))/2,[1 3 2]);
xmod=H2*z';
xq=xmid(:,ones(nIntP,1),:)+xmod(:,:,ones(1,nSubInt));
wmod=H2*wt';
wq=wmod(:,:,ones(1,nSubInt));
xq=reshape(xq(:),n,[]);
f=feval(fun,xq,varargin{:});
wq=reshape(wq(:),n,[]);
I=sum(wq.*f,2);

