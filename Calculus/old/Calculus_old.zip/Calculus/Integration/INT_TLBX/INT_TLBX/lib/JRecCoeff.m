function ab=JRecCoeff(N,a,b)
% Recurrence coefficients for monic Jacobi polynomials in the interval
% [-1,1].
%
% Description
%     #ab#=JRecCoeff(#N#,#a#,#b#)
%     generates the first #N# recurrence coefficients for monic Jacobi
%     polynomials in the interval [-1,1] with parameters #a# and #b#. These
%     are orthogonal on [-1,1] with respect to the Jacobi weight function
%     w(t) = (1-t)^#a# * (1+t)^#b#, namely:
%     int(Jn(t)*Jm(t)*w(t),t,-1,1)=||Jn||^2*Delta(m,n)
%     where Delta(m,n)=1 if m=n and 0 otherwise.
%     Explicit formulas for these calculations are contained in: Yang Chen
%     & Mourad Ismail, Jacobi polynomials from compatibility conditions,
%     Proc. Amer. Math. Soc., 133 (2004), pp. 465�472 and more specifically
%     formulas (2.15) and (2.18).
%     #ab#=JRecCoeff(#N#,#a#) is the same as #ab#=JRecCoeff(#N#,#a#,#a#) and
%     #ab#=JRecCoeff(#N#) the same as #ab#=JRecCoeff(#N#,0,0).
%
% Input arguments
%     #N# (scalar) is the number of the first recurrence coefficients for
%     monic Jacobi polynomials to be calculated.
%     #a# (scalar) is a parameter of the monic Jacobi polynomials, as
%     described above.
%     #b# (scalar) is a parameter of the monic Jacobi polynomials, as
%     described above.
%
% Output arguments
%     #ab# ([#N# x 2]) contains the #N# alpha coefficients in its first
%     column and the #N# beta coefficients in its second column.
%
% Parents (calling functions)
%     GKIntP > JRecCoeff
%
% Children (called functions)
%     JRecCoeff >
%

% __________________________________________________________________________
%% Copyright
%
%  (c) 2016 by George Papazafeiropoulos
%  Captain, Infrastructure Engineer, Hellenic Air Force
%  Civil Engineer, M.Sc., Ph.D. candidate, NTUA
%
% Email: gpapazafeiropoulos@yahoo.gr
%
% Website: http://users.ntua.gr/gpapazaf/
%

if nargin<2
    a=0;
end
if nargin<3
    b=a;
end
if ((N<=0) || (a<=-1) || (b<=-1))
    error('Parameter(s) out of range')
end
nu=(b-a)/(a+b+2);
mu=2^(a+b+1)*gamma(a+1)*gamma(b+1)/gamma(a+b+2);
if N==1
    ab=[nu mu];
    return
end 
N=N-1;
n=1:N;
nab=2*n+a+b;
A=[nu (b^2-a^2)*ones(1,N)./(nab.*(nab+2))];
B=[mu 4*(n+a).*(n+b).*n.*(n+a+b)./((nab.^2).*(nab+1).*(nab-1))];
ab=[A' B'];

