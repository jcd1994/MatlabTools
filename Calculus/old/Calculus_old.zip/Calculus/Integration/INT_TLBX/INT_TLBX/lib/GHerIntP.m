function [x,w]=GHerIntP(nGH)
% Gauss-Hermite integration points
%
% Description
%     [#x#,#w#]=GHerIntP(#nGH#)
%     calculates the abscissas (x) and weights (w) for the Gauss-Hermite
%     quadrature. The algorithm presented here is described in J. A.
%     Gubner, Gaussian quadrature and the eigenvalue problem, October 16,
%     2014.
%
% Input arguments
%     #nGH# (scalar) is the number of the integration points to be
%     calculated.
%
% Output arguments
%     #x# ([#nGH# x 1]) contains the coordinates of the integration points.
%     #w# ([#nGH# x 1]) contains the weights of the integration points.
%
% Parents (calling functions)
%     GHerQuad > GHerIntP
%
% Children (called functions)
%     GHerIntP >
%

% __________________________________________________________________________
%% Copyright
%
%  (c) 2016 by George Papazafeiropoulos
%  Captain, Infrastructure Engineer, Hellenic Air Force
%  Civil Engineer, M.Sc., Ph.D. candidate, NTUA
%
% Email: gpapazafeiropoulos@yahoo.gr
%
% Website: http://users.ntua.gr/gpapazaf/
%

% upper diagonal of Jacobi matrix
u=sqrt((1:nGH-1)/2); 
[V,D]=eig(diag(u,1)+diag(u,-1));
[x,ix]=sort(diag(D));
w=sqrt(pi)*V(1,ix)'.^2;

