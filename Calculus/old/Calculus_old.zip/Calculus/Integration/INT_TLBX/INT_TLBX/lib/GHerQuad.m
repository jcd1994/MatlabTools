function [I,xq,wq]=GHerQuad(fun,nIntP,varargin)
% Composite Gauss-Hermite quadrature
%
% Description
%     [#I#,#xq#,#wq#]=GHerQuad(#fun#,#a#,#b#,#nSubInt#,#nIntP#,#varargin#)
%     calculates the approximate value of the definite integral from -Inf
%     to Inf of exp(-x^2)*#fun#(x)*dx. Between #I#, #xq# and #wq# the
%     following equality holds:
%     #I#=sum(#wq#.*feval(#fun#,#xq#,varargin{:}),2)
%
% Input arguments
%     #fun# (function handle or name of m file defining a function) is the
%     unweighted function to be integrated.
%     #nIntP# (scalar) is the number of integration points at which the
%     function #fun# will be evaluated at each subinterval.
%     #varargin# (cell) contains additional arguments to be passed to the
%     function #fun# in order to be evaluated.
%
% Output arguments
%     #I# (scalar) is the approximate value of the definite integral.
%     #xq# ([#nIntP# x 1]) is the nodes used for the quadrature.
%     #wq# ([#nIntP# x 1]) is the weights used for the
%     quadrature.
%
% Parents (calling functions)
%     > GHerQuad
%
% Children (called functions)
%     GHerQuad > GHerIntP
%

% __________________________________________________________________________
%% Copyright
%
%  (c) 2016 by George Papazafeiropoulos
%  Captain, Infrastructure Engineer, Hellenic Air Force
%  Civil Engineer, M.Sc., Ph.D. candidate, NTUA
%
% Email: gpapazafeiropoulos@yahoo.gr
%
% Website: http://users.ntua.gr/gpapazaf/
%

[xq,wq]=GHerIntP(nIntP);
f=feval(fun,xq,varargin{:});
I=wq'*f;

