function [x,w]=CCIntP(nCC)
% Clenshaw-Curtis integration points in the interval [-1,1].
%
% Description
%     [#x#,#w#]=CCIntP(#nCC#)
%     generates the #nCC#-point Clenshaw-Curtis quadrature rule. It
%     calculates the abscissas (#x#) and weights (#w#) for the
%     Clenshaw-Curtis quadrature.
%
% Input arguments
%     #nCC# (scalar) is the number of the integration points to be
%     calculated.
%
% Output arguments
%     #x# ([#nCC# x 1]) contains the coordinates of the integration points.
%     #w# ([#nCC# x 1]) contains the weights of the integration points.
%
% Parents (calling functions)
%     CCQuad > CCIntP
%
% Children (called functions)
%     CCIntP >
%

% __________________________________________________________________________
%% Copyright
%
%  (c) 2016 by George Papazafeiropoulos
%  Captain, Infrastructure Engineer, Hellenic Air Force
%  Civil Engineer, M.Sc., Ph.D. candidate, NTUA
%
% Email: gpapazafeiropoulos@yahoo.gr
%
% Website: http://users.ntua.gr/gpapazaf/
%


if nCC==1
    w=2;
    x=0;
elseif nCC==2
    w=[1;1];
    x=[-1;1];
else
    N=nCC-1;
    c=zeros(nCC,2);
    c(1:2:nCC,1)=(2./[1 1-(2:2:N).^2 ])';
    c(2,2)=1;
    f=real(ifft([c(1:nCC,:);c(N:-1:2,:)]));
    w=2*([f(1,1); 2*f(2:N,1); f(nCC,1)])/2;
    x=N*f(nCC:-1:1,2);
end

