function [x,w]=GCIntP(nGC)
% Gauss-Chebyshev integration points in the interval [-1,1].
%
% Description
%     [#x#,#w#]=GCIntP(#nGC#)
%     calculates the abscissas (x) and weights (w) for the Gauss-Chebyshev
%     quadrature.
%
% Input arguments
%     #nGC# (scalar) is the number of the integration points to be
%     calculated.
%
% Output arguments
%     #x# ([#nGC# x 1]) contains the coordinates of the integration points.
%     #w# ([#nGC# x 1]) contains the weights of the integration points.
%
% Parents (calling functions)
%     GCQuad > GCIntP
%
% Children (called functions)
%     GCIntP >
%

% __________________________________________________________________________
%% Copyright
%
%  (c) 2016 by George Papazafeiropoulos
%  Captain, Infrastructure Engineer, Hellenic Air Force
%  Civil Engineer, M.Sc., Ph.D. candidate, NTUA
%
% Email: gpapazafeiropoulos@yahoo.gr
%
% Website: http://users.ntua.gr/gpapazaf/
%

x=cos((1:2:2*nGC)*pi/(2*nGC));
x=x(end:-1:1)';
w=pi/nGC*ones(nGC,1);

