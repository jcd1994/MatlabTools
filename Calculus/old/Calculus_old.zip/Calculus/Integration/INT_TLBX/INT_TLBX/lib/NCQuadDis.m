function [I,xq,wq]=NCQuadDis(x,f,nIntP)
% Newton-Cotes quadrature for equally spaced discrete data
%
% Description
%     [#I#,#xq#,#wq#]=NCQuadDis(#fun#,#a#,#b#,#nSubInt#,#nIntP#,#varargin#)
%     calculates the approximate value of the definite integral from #a# to
%     #b# of #fun#(x)*dx, in the case that #f# is defined by tabular data
%     and therefore the values of #x# cannot be changed arbitrarily. In
%     order to apply properly the Newton-Cotes quadrature, the fraction
%     (length(#x#)-1)/(#nIntP#-1)=(length(#f#)-1)/(#nIntP#-1) must be
%     integer (it is equal to the number of subintervals #nSubInt# used for
%     the quadrature). Between #I#, #f# and #wq# the following equality
%     holds: #I#=#wq#'*#f#
%
% Input arguments
%     #x# ([#n# x 1]) is the vector of independent variable data. It is
%     assumed to be equally spaced.
%     #f# ([#n# x 1]) is the vector of the discrete function values to be
%     integrated.
%     #nIntP# (scalar) is the number of the discrete function values
%     (integration points) of #f# at each subinterval to be integrated.
%
% Output arguments
%     #I# (scalar) is the approximate value of the definite integral of #f#
%     with respect to #x#.
%     #xq# ([#nSubInt#*#nIntP# x 1]) is the nodes used for the quadrature.
%     #wq# ([#nSubInt#*#nIntP# x 1]) is the weights used for the
%     quadrature.
%
% Parents (calling functions)
%     > NCQuadDis
%
% Children (called functions)
%     NCQuadDis > NCIntP
%

% __________________________________________________________________________
%% Copyright
%
%  (c) 2016 by George Papazafeiropoulos
%  Captain, Infrastructure Engineer, Hellenic Air Force
%  Civil Engineer, M.Sc., Ph.D. candidate, NTUA
%
% Email: gpapazafeiropoulos@yahoo.gr
%
% Website: http://users.ntua.gr/gpapazaf/
%

n=length(f);
if length(x)~=n
    error('Dimensions of x and f are different');
end
[~,wt]=NCIntP(nIntP-1);
nSubInt=(n-1)/(nIntP-1);
H=(x(end)-x(1))/nSubInt;
evalf=reshape(f(1:end-1),nIntP-1,nSubInt);
evalf=[evalf;[evalf(1,2:end),f(end)]];
I=H*sum(wt'*evalf);
xq=reshape(x(1:end-1),nIntP-1,nSubInt);
xq=[xq;[xq(1,2:end),x(end)]];
xq=xq(:);
wq=H*wt(:,ones(1,nSubInt));
wq=wq(:);

