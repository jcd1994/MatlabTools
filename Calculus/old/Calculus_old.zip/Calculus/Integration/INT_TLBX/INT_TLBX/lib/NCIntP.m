function [x,w]=NCIntP(m)
% Newton-Cotes integration points in the interval [-1,1].
%
% Description
%     [#x#,#w#]=NCIntP(#m#)
%     calculates the abscissas (x) and weights (w) for the Newton-Cotes
%     quadrature.
%
% Input arguments
%     #m# (scalar) is the order of quadrature. Set #m#=1 for the
%     trapezoidal rule, #m#=2 for Simpson's 1/3 rule, #m#=3 for Simpson's
%     3/8 rule, etc. The number of integration points will be #m#+1.
%
% Output arguments
%     #x# ([#m#+1 x 1]) contains the coordinates of the integration points.
%     #w# ([#m#+1 x 1]) contains the weights of the integration points.
%
% Parents (calling functions)
%     NCQuad > NCIntP
%
% Children (called functions)
%     NCIntP >
%

% __________________________________________________________________________
%% Copyright
%
%  (c) 2016 by George Papazafeiropoulos
%  Captain, Infrastructure Engineer, Hellenic Air Force
%  Civil Engineer, M.Sc., Ph.D. candidate, NTUA
%
% Email: gpapazafeiropoulos@yahoo.gr
%
% Website: http://users.ntua.gr/gpapazaf/
%

h=2/m;
x=(-1:h:1)';
A=cumprod([ones(1,m+1);cumsum(ones(m,m+1),2)]);
mv=1:m+1;
c=((m+1).^mv-1)./(m*mv);
w=A\c';

