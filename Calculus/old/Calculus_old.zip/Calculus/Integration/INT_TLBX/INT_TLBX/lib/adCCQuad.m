function [I,xq,wq]=adCCQuad(fun,a,b,nSubInt,nIntP,tol,maxLevel,level,I1,varargin)
% Adaptive Clenshaw-Curtis quadrature.
%
% Description
%     [#I#,#xq#,#wq#]=adCCQuad(#fun#,#a#,#b#,#tol#,#maxLevel#,#level#,#I1#,#varargin#)
%     performs adaptive Clenshaw-Curtis quadrature and automatic interval
%     subdivision through recursion (the function calls itself). The
%     refinement proceeds by bisecting the successive integration intervals
%     until the difference between levels is lower than a specified
%     tolerance. Between #I#, #xq# and #wq# the following equality holds:
%     #I#=sum(#wq#.*feval(#fun#,#xq#,varargin{:}),2)
%
% Input arguments
%     #fun# (function handle or name of m file defining a function) is the
%     function to be integrated.
%     #a# ([#n# x 1]) is the lower limit of the integration interval.
%     #b# ([#n# x 1]) is the upper limit of the integration interval.
%     #nSubInt# (scalar) is the number of equal subintervals of the
%     interval [#a#,#b#] at which the function #fun# will be integrated at
%     each level.
%     #nIntP# (scalar) is the number of integration points at which the
%     function #fun# will be evaluated at each subinterval at each level.
%     #tol# ([2 x 1]) contains the relative and absolute tolerances for
%     changes in numerical value of integral. Refinement is stopped when
%     abs(#I1#-#I2#) < max(#tol#(1)*#I1#,#tol#(2)) where #I1# and #I2# are
%     values of integral on level 1 (coarser) and level 2 (finer), #tol#(1)
%     is the relative tolerance, and #tol#(2) is the absolute tolerance.
%     #maxLevel# (scalar) is the maximum number of refinements. It
%     corresponds to 2^(#maxLevel#-1) subintervals of length
%     h=(#b#-#a#)/(2^(#maxLevel#-1)) each.
%     #level# (scalar) is the local refinement level. Specify always
%     #level#=0 when calling the function (on startup).
%     #I1# (scalar) is the current value of the definite integral on the
%     current level. Specify always #I1#=0 when calling the function (on
%     startup).
%     #varargin# (cell) contains additional arguments to be passed to the
%     function #fun# in order to be evaluated.
%
% Output arguments
%     #I# ([#n# x 1]) is the approximate value of the definite integral.
%     #xq# ([#n# x k]) is the nodes used for the quadrature.
%     #wq# ([#n# x k]) is the weights used for the quadrature.
%
% Parents (calling functions)
%     adCCQuad > adCCQuad
%
% Children (called functions)
%     adCCQuad > CCQuad
%     adCCQuad > adCCQuad
%

% __________________________________________________________________________
%% Copyright
%
%  (c) 2016 by George Papazafeiropoulos
%  Captain, Infrastructure Engineer, Hellenic Air Force
%  Civil Engineer, M.Sc., Ph.D. candidate, NTUA
%
% Email: gpapazafeiropoulos@yahoo.gr
%
% Website: http://users.ntua.gr/gpapazaf/
%


% Current refinement level
level=level+1;
% Evaluate I1 on first call
if level==1
    I1=CCQuad(fun,a,b,nSubInt,nIntP,varargin{:});
end
c=a+0.5*(b-a);
[I2l,x2ql,w2ql]=CCQuad(fun,a,c,nSubInt,nIntP,varargin{:});
[I2r,x2qr,w2qr]=CCQuad(fun,c,b,nSubInt,nIntP,varargin{:});
I2=I2l+I2r;
x2q=[x2ql x2qr];
w2q=[w2ql w2qr];
% Issue a warning if recursion limit is exceeded
if level>maxLevel
    warning('In adCCQuad: level = %d exceeds the specified limit\n',level);
    % Stop the recursion if recursion limit is exceeded by 2
    if level>maxLevel+2
        fprintf('Refinement is halted, recursion limit is exceeded by 2\n');
        I=I2;
        xq=x2q;
        wq=w2q;
        return;
    end
end
% If the difference between levels is lower than tolerance, stop the
% recursion and accept the fine level result, else subdivide further
if all(abs(I2-I1) < max(tol(1)*abs(I1),tol(2)))
    I=I2;
    xq=x2q;
    wq=w2q;
    return;
else
    % I_left
    [Il,xql,wql]=adCCQuad(fun,a,c,nSubInt,nIntP,[tol(1);tol(2)/2],maxLevel,level,I2l,varargin{:});
    % I_right
    [Ir,xqr,wqr]=adCCQuad(fun,c,b,nSubInt,nIntP,[tol(1);tol(2)/2],maxLevel,level,I2r,varargin{:});
    I=Il+Ir;
    xq=[xql xqr];
    wq=[wql wqr];
end

