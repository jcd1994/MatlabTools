function [I,xq,wq]=RombQuad(fun,a,b,m,varargin)
% Romberg quadrature
%
% Description
%     [#I#,#xq#,#wq#]=RombQuad(#fun#,#a#,#b#,#m#,#varargin#)
%     calculates the approximate value of the definite integral from #a# to
%     #b# of #fun#(x)*dx according to the Romberg's method. In this method,
%     the interval [#a#,#b#] is separated into equal subintervals of length
%     #h# each, for #m#-1 times. Each time, a first approximation for the
%     definite integral requested is obtained through the application of
%     the trapezoidal rule for #fun# from #a# to #b# with step #h#. This
%     approximation is stored in #R#. After this the Richardson
%     extrapolation is applied repeatedly at the integral approximations
%     stored in #R#. Between #I#, #xq# and #wq# the following equality
%     holds: #I#=sum(#wq#.*feval(#fun#,#xq#,varargin{:}),2)
%
% Input arguments
%     #fun# (function handle, or inline function, or name of m file
%     defining a function) is the function to be integrated. It must be
%     vectorized.
%     #a# ([#n# x 1]) is the lower limit of the integration interval.
%     #b# ([#n# x 1]) is the upper limit of the integration interval.
%     #m# (scalar) is the exponent in the relative error. The estimated
%     relative error is of order 1e-#m#.
%     #varargin# (cell) contains additional arguments to be passed to the
%     function #fun# in order to be evaluated.
%
% Output arguments
%     #I# ([#n# x 1]) is the approximate value of the definite integral from
%     #a# to #b# of #fun#(x)*dx.
%     #xq# ([#n# x 2^(#m#-1)+1]) is the nodes used for the quadrature.
%     #wq# ([#n# x 2^(#m#-1)+1]) is the weights used for the quadrature.
%
% Parents (calling functions)
%     > RombQuad
%
% Children (called functions)
%     RombQuad >
%

% __________________________________________________________________________
%% Copyright
%
%  (c) 2016 by George Papazafeiropoulos
%  Captain, Infrastructure Engineer, Hellenic Air Force
%  Civil Engineer, M.Sc., Ph.D. candidate, NTUA
%
% Email: gpapazafeiropoulos@yahoo.gr
%
% Website: http://users.ntua.gr/gpapazaf/
%


a=a(:);
b=b(:);
n=numel(a);
if numel(b)~=n
    error('Lower and upper limits must have the same size')
end
fun=fcnchk(fun);
try
    fa=feval(fun,a,varargin{:});
    fb=feval(fun,b,varargin{:});
catch err1
    error('The integrand must be defined in [a,b]')
end
if numel(fa)~=n || numel(fb)~=n
    error('The integrand must be scalar valued')
end
try
    feval(fun,a(:,[1 1]),varargin{:});
catch err1
    error('The integrand must be vectorized')
end
% Preallocation
R=zeros(n,2,m);
wq=zeros(n,2,m,2^(m-1)+1);
% Function evaluations
H=(b-a)/2^(m-1);
xq=a(:,ones(1,2^(m-1)+1))+cumsum([zeros(n,1),H(:,ones(1,2^(m-1)))],2);
f1=feval(fun,xq,varargin{:});
% Initial trapezoidal quadrature
h=b-a;
R(:,1,1)=h.*(f1(:,1)+f1(:,end))/2;
wq(:,1,1,1)=h/2;
wq(:,1,1,end)=h/2;
for i=2:m
    % Trapezoidal quadrature
    st=2^(m-i+1);
    ind=(st/2)+1:st:2^(m-1);
    R(:,2,1)=(R(:,1,1)+h.*sum(f1(:,ind),2))/2;
    wq(:,2,1,:)=wq(:,1,1,:)/2;
    wq(:,2,1,ind)=wq(:,2,1,ind)+h(:,1,1,ones(1,numel(ind)))/2;
    % Richardson extrapolation
    for k=1:i-1
        R(:,2,k+1)=(4^k*R(:,2,k)-R(:,1,k))/(4^k-1);
        wq(:,2,k+1,:)=(4^k*wq(:,2,k,:)-wq(:,1,k,:))/(4^k-1);
    end
    % Update
    R(:,1,1:i)=R(:,2,1:i);
    wq(:,1,1:i,:)=wq(:,2,1:i,:);
    h=h/2;
end
I=R(:,1,m);
wq=reshape(wq(:,1,m,:),[n,2^(m-1)+1,1,1]);

