function [x,w]=GLagIntP(nGL)
% Gauss-Laguerre integration points
%
% Description
%     [#x#,#w#]=GLagIntP(#nGL#)
%     calculates the abscissas (x) and weights (w) for the Gauss-Laguerre
%     quadrature. The algorithm presented here is described in J. A.
%     Gubner, Gaussian quadrature and the eigenvalue problem, October 16,
%     2014.
%
% Input arguments
%     #nGL# (scalar) is the number of the integration points to be
%     calculated.
%
% Output arguments
%     #x# ([#nGL# x 1]) contains the coordinates of the integration points.
%     #w# ([#nGL# x 1]) contains the weights of the integration points.
%
% Parents (calling functions)
%     GLagQuad > GLagIntP
%
% Children (called functions)
%     GLagIntP >
%

% __________________________________________________________________________
%% Copyright
%
%  (c) 2016 by George Papazafeiropoulos
%  Captain, Infrastructure Engineer, Hellenic Air Force
%  Civil Engineer, M.Sc., Ph.D. candidate, NTUA
%
% Email: gpapazafeiropoulos@yahoo.gr
%
% Website: http://users.ntua.gr/gpapazaf/
%

% Jacobi matrix
J=diag(1:2:2*nGL-1)-diag(1:nGL-1,1)-diag(1:nGL-1,-1);
[V,D]=eig(J);
[x,ix]=sort(diag(D));
w=V(1,ix)'.^2;

