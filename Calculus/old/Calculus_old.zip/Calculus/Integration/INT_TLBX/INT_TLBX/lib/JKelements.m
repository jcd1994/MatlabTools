function ab=JKelements(N,ab0)
% Elements of the Jacobi-Kronrod matrix.
%
% Description
%     #ab#=JKelements(#N#,#ab0#)
%     produces the alpha- and beta- elements in the Jacobi-Kronrod matrix
%     of order 2*#N#+1 for the weight function (or measure) w(t) =
%     (1-t)^a * (1+t)^b, defined by the recurrence coefficients of the
%     associated orthogonal polynomials, which are stored in the array
%     #ab0#. #ab# refers to the interval [0 1].
%     The pseudocode for the algorithm is in the Appendix A of: Dirk P.
%     Laurie, Calculation of Gauss-Kronrod quadrature rules, Mathematics of
%     Computation, Vol.66, No.219, July 1997, pp.1133-1145.
%
% Input arguments
%     #N# = floor(#nK#/2), where #nK# (scalar) is the number of the Kronrod
%     integration points.
%     #ab0# ([2*#N# x 2] for Gauss-Kronrod integration) contains
%     information about the weight function w(t) as defined in the
%     description, through the recurrence coefficients of the associated
%     orthogonal polynomials. Its minimum dimensions are [ceil(3*#N#/2)+1 x
%     2]. It contains the alpha coefficients in its first column and the
%     beta coefficients in its second column. The recurrence coefficients
%     contained in #ab0# refer to the interval [0 1].
%
% Output arguments
%     #ab# ([2*#N#+1 x 2]) contains the alpha-elements of the
%     Jacobi-Kronrod matrix in its first column and the beta-elements of
%     the Jacobi-Kronrod matrix in its second column.
%
% Parents (calling functions)
%     GKIntP > JKelements
%
% Children (called functions)
%     JKelements >
%

% __________________________________________________________________________
%% Copyright
%
%  (c) 2016 by George Papazafeiropoulos
%  Captain, Infrastructure Engineer, Hellenic Air Force
%  Civil Engineer, M.Sc., Ph.D. candidate, NTUA
%
% Email: gpapazafeiropoulos@yahoo.gr
%
% Website: http://users.ntua.gr/gpapazaf/
%

if length(ab0)<ceil(3*N/2)+1
    error('Array ab0 is too short')
end
a=zeros(2*N+1,1);
b=a;
k=0:floor(3*N/2);
a(k+1)=ab0(k+1,1);
k=0:ceil(3*N/2);
b(k+1)=ab0(k+1,2);
s=zeros(floor(N/2)+2,1);
t=s;
t(2)=b(N+2);
for m=0:N-2
    k=floor((m+1)/2):-1:0;
    l=m-k;
    s(k+2)=cumsum((a(k+N+2)-a(l+1)).*t(k+2)+b(k+N+2).*s(k+1)-b(l+1).*s(k+2));
    swap=s;
    s=t;
    t=swap;
end
j=floor(N/2):-1:0;
s(j+2)=s(j+1);
for m=N-1:2*N-3
    k=m+1-N:floor((m-1)/2);
    l=m-k;
    j=N-1-l;
    s(j+2)=cumsum(-(a(k+N+2)-a(l+1)).*t(j+2)-b(k+N+2).*s(j+2)+b(l+1).*s(j+3));
    j=j(length(j));
    k=floor((m+1)/2);
    if rem(m,2)==0
        a(k+N+2)=a(k+1)+(s(j+2)-b(k+N+2)*s(j+3))/t(j+3);
    else
        b(k+N+2)=s(j+2)/s(j+3);
    end
    swap=s;
    s=t;
    t=swap;
end
a(2*N+1)=a(N)-b(2*N+1)*s(2)/t(2);
ab=[a b];

