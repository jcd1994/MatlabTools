function [I,xq,wq]=TrapQuadDis(x,f)
% Trapezoid rule for arbitrarily spaced discrete data
%
% Description
%     [#I#,#xq#,#wq#]=TrapQuad(#fun#,#a#,#b#,#nSubInt#,#varargin#)
%     calculates the approximate value of the definite integral of #f# with
%     respect to #x# according to the composite trapezoid rule, in the case
%     that #f# is defined by tabular data and therefore the values of #x#
%     cannot be changed arbitrarily.
%
% Input arguments
%     #x# ([#n# x 1]) is the vector of independent variable data. It can
%     be equally or unequally spaced.
%     #f# ([#n# x 1]) is the vector of the discrete function values to be
%     integrated.
%
% Output arguments
%     #I# (scalar) is the approximate value of the definite integral of #f#
%     with respect to #x#.
%     #xq# ([#n#-1 x 1]) is the nodes used for the quadrature.
%     #wq# ([#n#-1 x 1]) is the weights used for the quadrature.
%
% Parents (calling functions)
%     > TrapQuadDis
%
% Children (called functions)
%     TrapQuadDis >
%

% __________________________________________________________________________
%% Copyright
%
%  (c) 2016 by George Papazafeiropoulos
%  Captain, Infrastructure Engineer, Hellenic Air Force
%  Civil Engineer, M.Sc., Ph.D. candidate, NTUA
%
% Email: gpapazafeiropoulos@yahoo.gr
%
% Website: http://users.ntua.gr/gpapazaf/
%

n=length(f);
if length(x)~=n
    error('Dimensions of x and f are different');
end
% values of x(i+1)-x(i)
dx=diff(x);
% average values of f
avef=f(1:n-1)+0.5*diff(f);
I=sum(avef.*dx);
xq=x(1:n-1)+0.5*dx;
wq=ones(n-1,1);

