function [x,w]=GLobIntP(nGL)
% Gauss-Lobatto integration points in the interval [-1,1].
%
% Description
%     [#x#,#w#]=GLobIntP(#nGL#)
%     calculates the abscissas (x) and weights (w) for the Gauss-Lobatto
%     quadrature. The algorithm presented here is described in J. A.
%     Gubner, Gaussian quadrature and the eigenvalue problem, October 16,
%     2014 and Z. S. Zheng, G.H. Huang, Computation for Jacobi�Gauss
%     Lobatto quadrature based on derivative relation, Poster, in:
%     Proceedings of Modeling in Geosciences, 2010.
%
% Input arguments
%     #nGL# (scalar) is the number of the integration points to be
%     calculated, including the interval ends (-1,1).
%
% Output arguments
%     #x# ([#nGL# x 1]) contains the coordinates of the integration points.
%     #w# ([#nGL# x 1]) contains the weights of the integration points.
%
% Parents (calling functions)
%     GLobQuad > GLobIntP
%
% Children (called functions)
%     GLobIntP >
%

% __________________________________________________________________________
%% Copyright
%
%  (c) 2016 by George Papazafeiropoulos
%  Captain, Infrastructure Engineer, Hellenic Air Force
%  Civil Engineer, M.Sc., Ph.D. candidate, NTUA
%
% Email: gpapazafeiropoulos@yahoo.gr
%
% Website: http://users.ntua.gr/gpapazaf/
%

if nGL==1
    x=-1;
    w=2;
else
    N=nGL-2;
    beta=(1:N)./sqrt(4*(1:N).^2-1);
    J1=diag(beta,-1)+diag(beta,1);
    J=[J1,[zeros(N,1);sqrt((N+1)/(2*N+1))];
        [zeros(1,N),sqrt((N+1)/(2*N+1))],0];
    [V,D]=eig(J);
    [x,ix]=sort(diag(D));
    w=2*V(1,ix)'.^2;
end

