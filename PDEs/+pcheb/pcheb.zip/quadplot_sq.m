function quadplot_sq(x,U,xx,C)
%QUADPLOT_SQ  Invoke QUADPLOT in square mode.

    quadplot(x,x,U,xx,xx,C,C,1)

end
