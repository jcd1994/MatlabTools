function f = f17(x,y)
%F17  Test function (Trefethen, Problem 17).

    f = exp(-10*( (x - 1/2).^2 + (y - 1).^2 ));

end

