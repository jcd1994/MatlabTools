function contour_sq(x,U)
%UNTITLED7 Summary of this function goes here
%   Detailed explanation goes here

    mycontour(x,x,U,1)

end

