function drawgrid_sq(x)
%DRAWGRID_SQ  Show domain decomposition for SOLVE_LIN_SQ_{SYM,GEN}.

    drawgrid_rect(x,x),  axis_sq

end
