function f = fzero(x,~)
%FZERO  The null function f(x,y) = 0.

    f = zeros(size(x));

end

