function quadplot_lwise(x,U,xx,C)
%QUADPLOT_LWISE  Invoke QUADPLOT in L-wise mode.

    quadplot(x,x,U,xx,xx,C,C,3)

end
