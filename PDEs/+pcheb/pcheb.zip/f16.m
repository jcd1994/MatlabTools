function f = f16(x,y)
%F16  Test function (Trefethen, Problem 16).

    f = 10*sin(8*x.*(y - 1));

end

