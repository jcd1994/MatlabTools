/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * refineGrid3D_conv_data.c
 *
 * Code generation for function 'refineGrid3D_conv_data'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "refineGrid3D_conv.h"
#include "refineGrid3D_conv_data.h"

/* Variable Definitions */
emlrtCTX emlrtRootTLSGlobal = NULL;
const volatile char_T *emlrtBreakCheckR2012bFlagVar;
emlrtContext emlrtContextGlobal = { true, false, 131418U, NULL,
  "refineGrid3D_conv", NULL, false, { 2045744189U, 2170104910U, 2743257031U,
    4284093946U }, NULL };

/* End of code generation (refineGrid3D_conv_data.c) */
