#define FADDEEVA_FUNC Faddeeva::w
#define FADDEEVA_REAL 0
#include "Faddeeva_mex.cc"
